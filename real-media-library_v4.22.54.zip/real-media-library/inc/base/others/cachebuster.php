<?php
// Cachebusters generated on 2025-09-04 13:44:26
return [
	'src/public/dist/i18n-dependency-map-default-lite.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/i18n-dependency-map-default-pro.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/rml.css'=> '1fa951812e87457dd426a240529bd4ea',
	'src/public/dist/rml.css.map'=> '291ed5e824e753a1cd5afd2c9a275d72',
	'src/public/dist/rml.lite.js'=> 'c8d2aea179845b0bb431526f6c70b4ad',
	'src/public/dist/rml.lite.js.LICENSE.txt'=> 'ebcfe48e908f2dfae4a8e7b29457221b',
	'src/public/dist/rml.lite.js.map'=> '00a1bcb2a263985ab0f18ccc6ab66b64',
	'src/public/dist/rml.pro.js'=> '52f88579dccc1530c396fb5193dcc2e6',
	'src/public/dist/rml.pro.js.LICENSE.txt'=> 'ebcfe48e908f2dfae4a8e7b29457221b',
	'src/public/dist/rml.pro.js.map'=> 'f87aa94f668268d14b3070fc4bf5bd5f',
	'src/public/dist/rml_gutenberg.lite.js'=> '5398b12495e3228088bedb8f9de4edab',
	'src/public/dist/rml_gutenberg.lite.js.map'=> '8d33a36dd952742b8b2d768aa578cc5c',
	'src/public/dist/rml_gutenberg.lite.js.pot'=> '43b22b0ff1681d57cfabd31528efba0f',
	'src/public/dist/rml_gutenberg.pro.js'=> '9c9e873f36461eb19618338cf750c5a1',
	'src/public/dist/rml_gutenberg.pro.js.map'=> '8c661a30e6dcd2205f438c58558cfe2e',
	'src/public/dist/rml_gutenberg.pro.js.pot'=> '36dd2b222c3004c5ea5f86281c58daa8',
	'src/public/dist/rml_shortcode.lite.js'=> '39043520fc8d313d15d6c35f87614690',
	'src/public/dist/rml_shortcode.lite.js.LICENSE.txt'=> '6a911229c23259c3812393dade2e7199',
	'src/public/dist/rml_shortcode.lite.js.map'=> '860c3d5afd26162baa1943991c430bb0',
	'src/public/dist/rml_shortcode.pro.js'=> '6914980133af9b9f9246544e42d7b90f',
	'src/public/dist/rml_shortcode.pro.js.LICENSE.txt'=> '6a911229c23259c3812393dade2e7199',
	'src/public/dist/rml_shortcode.pro.js.map'=> 'ae10a3f2d5855984496953dd44d2c7a1'
];
