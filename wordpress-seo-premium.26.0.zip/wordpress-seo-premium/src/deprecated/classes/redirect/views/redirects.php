<?php
// phpcs:ignoreFile
/**
 * This view is deprecated and will be removed in a future version.
 *
 * @deprecated 25.7
 * @codeCoverageIgnore
 */
